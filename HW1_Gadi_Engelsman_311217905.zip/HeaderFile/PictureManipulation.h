#ifndef __PICGAME__
#define __PICGAME__

void picManipulat(int** mat);

#endif
