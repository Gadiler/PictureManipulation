#ifndef __NUMGAME__
#define __NUMGAME__

void numGame(int** numMat);

#endif
